import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { setCookie, getCookie } from "hono/cookie";
import OpenAI from "openai";
import { z } from "zod";
import { CreateExpenseSchema, CreateCategorySchema, UpdateCategorySchema, CreateIncomeSchema, CreateAccountSchema, UpdateAccountSchema, CreateTransferSchema } from "@/shared/types";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";

const app = new Hono<{ Bindings: Env }>();

// Authentication endpoints
app.get('/api/oauth/google/redirect_url', async (c) => {
  const redirectUrl = await getOAuthRedirectUrl('google', {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Get all expenses
app.get("/api/expenses", authMiddleware, async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    const stmt = c.env.DB.prepare("SELECT * FROM expenses WHERE user_id = ? ORDER BY date DESC, created_at DESC");
    const expenses = await stmt.bind(user.id).all();
    return c.json({ expenses: expenses.results });
  } catch (error) {
    console.error("Error fetching expenses:", error);
    return c.json({ error: "Failed to fetch expenses" }, 500);
  }
});

// Create new expense
app.post("/api/expenses", authMiddleware, zValidator("json", CreateExpenseSchema), async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    const data = c.req.valid("json");
    const stmt = c.env.DB.prepare(`
      INSERT INTO expenses (amount, description, category, date, account_id, user_id, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `);
    const result = await stmt.bind(data.amount, data.description, data.category, data.date, data.account_id, user.id).run();
    
    if (result.success) {
      const newExpense = await c.env.DB.prepare("SELECT * FROM expenses WHERE id = ?").bind(result.meta.last_row_id).first();
      return c.json({ expense: newExpense });
    } else {
      return c.json({ error: "Failed to create expense" }, 500);
    }
  } catch (error) {
    console.error("Error creating expense:", error);
    return c.json({ error: "Failed to create expense" }, 500);
  }
});

// Delete expense
app.delete("/api/expenses/:id", authMiddleware, async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    const id = c.req.param("id");
    const stmt = c.env.DB.prepare("DELETE FROM expenses WHERE id = ? AND user_id = ?");
    const result = await stmt.bind(id, user.id).run();
    
    if (result.success) {
      return c.json({ success: true });
    } else {
      return c.json({ error: "Failed to delete expense" }, 500);
    }
  } catch (error) {
    console.error("Error deleting expense:", error);
    return c.json({ error: "Failed to delete expense" }, 500);
  }
});

// Get AI insights
app.get("/api/insights", authMiddleware, async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    // Get recent expenses (last 30 days)
    const stmt = c.env.DB.prepare(`
      SELECT * FROM expenses 
      WHERE user_id = ? AND date >= date('now', '-30 days')
      ORDER BY date DESC
    `);
    const expenses = await stmt.bind(user.id).all();
    
    if (!expenses.results.length) {
      return c.json({ 
        insight: {
          summary: "Nenhuma despesa encontrada nos últimos 30 dias. Comece a rastrear suas despesas para obter insights personalizados!",
          tips: ["Comece adicionando suas despesas diárias", "Categorize seus gastos para uma melhor análise"],
          categoryBreakdown: {},
          spendingTrend: "stable"
        }
      });
    }

    // Calculate category breakdown
    const categoryBreakdown: Record<string, number> = {};
    let totalAmount = 0;
    
    expenses.results.forEach((expense: any) => {
      categoryBreakdown[expense.category] = (categoryBreakdown[expense.category] || 0) + expense.amount;
      totalAmount += expense.amount;
    });

    // Prepare data for AI analysis
    const expenseData = expenses.results.map((exp: any) => 
      `${exp.date}: R$${exp.amount} - ${exp.description} (${exp.category})`
    ).join('\n');

    const openai = new OpenAI({
      apiKey: c.env.OPENAI_API_KEY,
    });

    const completion = await openai.chat.completions.create({
      model: 'o4-mini',
      messages: [
        {
          role: 'system',
          content: `Você é um consultor financeiro pessoal. Analise os dados de despesas do usuário e forneça insights em português brasileiro. 
          Seja encorajador e prático. Foque em padrões, hábitos de gastos e conselhos práticos.
          Mantenha sua resposta concisa mas útil. Total gasto: R$${totalAmount.toFixed(2)}`
        },
        {
          role: 'user',
          content: `Por favor, analise minhas despesas dos últimos 30 dias e forneça insights:\n\n${expenseData}`
        }
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'expense_insights',
          schema: {
            type: 'object',
            properties: {
              summary: { 
                type: 'string',
                description: 'Uma breve visão geral dos padrões de gastos'
              },
              tips: { 
                type: 'array',
                items: { type: 'string' },
                description: 'Dicas práticas para economizar dinheiro baseadas nos gastos'
              },
              spendingTrend: { 
                type: 'string',
                enum: ['increasing', 'decreasing', 'stable'],
                description: 'Tendência geral nos gastos'
              }
            },
            required: ['summary', 'tips', 'spendingTrend'],
            additionalProperties: false
          },
          strict: true
        }
      }
    });

    const aiInsight = JSON.parse(completion.choices[0].message.content || '{}');
    
    return c.json({ 
      insight: {
        ...aiInsight,
        categoryBreakdown
      }
    });
  } catch (error) {
    console.error("Error generating insights:", error);
    return c.json({ error: "Failed to generate insights" }, 500);
  }
});

// Categorize expense using AI
app.post("/api/categorize", authMiddleware, zValidator("json", z.object({ description: z.string() })), async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    
    const { description } = c.req.valid("json");
    
    // Get user's categories
    const categoriesStmt = c.env.DB.prepare(`
      SELECT name FROM categories 
      WHERE user_id = ? OR is_default = 1
      ORDER BY is_default DESC, name ASC
    `);
    const categoriesResult = await categoriesStmt.bind(user.id).all();
    const categoryNames = categoriesResult.results.map((cat: any) => cat.name);
    
    const openai = new OpenAI({
      apiKey: c.env.OPENAI_API_KEY,
    });

    const completion = await openai.chat.completions.create({
      model: 'o4-mini',
      messages: [
        {
          role: 'system',
          content: `Categorize a descrição da despesa em uma destas categorias: 
          ${categoryNames.join(', ')}. 
          Retorne apenas o nome exato da categoria.`
        },
        {
          role: 'user',
          content: `Categorize esta despesa: "${description}"`
        }
      ],
      max_completion_tokens: 20
    });

    const category = completion.choices[0].message.content?.trim() || 'Outros';
    return c.json({ category });
  } catch (error) {
    console.error("Error categorizing expense:", error);
    return c.json({ category: 'Outros' });
  }
});

// Get all categories for user
app.get("/api/categories", authMiddleware, async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    
    const stmt = c.env.DB.prepare(`
      SELECT * FROM categories 
      WHERE user_id = ? OR is_default = 1
      ORDER BY is_default DESC, name ASC
    `);
    const categories = await stmt.bind(user.id).all();
    return c.json({ categories: categories.results });
  } catch (error) {
    console.error("Error fetching categories:", error);
    return c.json({ error: "Failed to fetch categories" }, 500);
  }
});

// Create new category
app.post("/api/categories", authMiddleware, zValidator("json", CreateCategorySchema), async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    
    const data = c.req.valid("json");
    
    // Check if category already exists for this user
    const existingStmt = c.env.DB.prepare(`
      SELECT id FROM categories 
      WHERE name = ? AND (user_id = ? OR is_default = 1)
    `);
    const existing = await existingStmt.bind(data.name, user.id).first();
    
    if (existing) {
      return c.json({ error: "Categoria já existe" }, 400);
    }
    
    const stmt = c.env.DB.prepare(`
      INSERT INTO categories (name, user_id, is_default, created_at, updated_at)
      VALUES (?, ?, 0, datetime('now'), datetime('now'))
    `);
    const result = await stmt.bind(data.name, user.id).run();
    
    if (result.success) {
      const newCategory = await c.env.DB.prepare("SELECT * FROM categories WHERE id = ?").bind(result.meta.last_row_id).first();
      return c.json({ category: newCategory });
    } else {
      return c.json({ error: "Failed to create category" }, 500);
    }
  } catch (error) {
    console.error("Error creating category:", error);
    return c.json({ error: "Failed to create category" }, 500);
  }
});

// Update category
app.put("/api/categories/:id", authMiddleware, zValidator("json", UpdateCategorySchema), async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    
    const id = c.req.param("id");
    const data = c.req.valid("json");
    
    // Check if category exists and belongs to user
    const categoryStmt = c.env.DB.prepare("SELECT is_default, user_id FROM categories WHERE id = ?");
    const category = await categoryStmt.bind(id).first() as any;
    
    if (!category) {
      return c.json({ error: "Categoria não encontrada" }, 404);
    }
    
    // Allow editing if it's the user's category OR if it's a default category
    if (!category.is_default && category.user_id !== user.id) {
      return c.json({ error: "Não autorizado" }, 403);
    }
    
    // Check if new name conflicts
    const existingStmt = c.env.DB.prepare(`
      SELECT id FROM categories 
      WHERE name = ? AND id != ? AND (user_id = ? OR is_default = 1)
    `);
    const existing = await existingStmt.bind(data.name, id, user.id).first();
    
    if (existing) {
      return c.json({ error: "Categoria já existe" }, 400);
    }
    
    const updateStmt = c.env.DB.prepare(`
      UPDATE categories 
      SET name = ?, updated_at = datetime('now')
      WHERE id = ?
    `);
    const result = await updateStmt.bind(data.name, id).run();
    
    if (result.success) {
      const updatedCategory = await c.env.DB.prepare("SELECT * FROM categories WHERE id = ?").bind(id).first();
      return c.json({ category: updatedCategory });
    } else {
      return c.json({ error: "Failed to update category" }, 500);
    }
  } catch (error) {
    console.error("Error updating category:", error);
    return c.json({ error: "Failed to update category" }, 500);
  }
});

// Get all income
app.get("/api/income", authMiddleware, async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    const stmt = c.env.DB.prepare("SELECT * FROM income WHERE user_id = ? ORDER BY date DESC, created_at DESC");
    const income = await stmt.bind(user.id).all();
    return c.json({ income: income.results });
  } catch (error) {
    console.error("Error fetching income:", error);
    return c.json({ error: "Failed to fetch income" }, 500);
  }
});

// Create new income
app.post("/api/income", authMiddleware, zValidator("json", CreateIncomeSchema), async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    const data = c.req.valid("json");
    const stmt = c.env.DB.prepare(`
      INSERT INTO income (amount, description, source, date, account_id, user_id, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `);
    const result = await stmt.bind(data.amount, data.description, data.source, data.date, data.account_id, user.id).run();
    
    if (result.success) {
      const newIncome = await c.env.DB.prepare("SELECT * FROM income WHERE id = ?").bind(result.meta.last_row_id).first();
      return c.json({ income: newIncome });
    } else {
      return c.json({ error: "Failed to create income" }, 500);
    }
  } catch (error) {
    console.error("Error creating income:", error);
    return c.json({ error: "Failed to create income" }, 500);
  }
});

// Delete income
app.delete("/api/income/:id", authMiddleware, async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    const id = c.req.param("id");
    const stmt = c.env.DB.prepare("DELETE FROM income WHERE id = ? AND user_id = ?");
    const result = await stmt.bind(id, user.id).run();
    
    if (result.success) {
      return c.json({ success: true });
    } else {
      return c.json({ error: "Failed to delete income" }, 500);
    }
  } catch (error) {
    console.error("Error deleting income:", error);
    return c.json({ error: "Failed to delete income" }, 500);
  }
});

// Get all accounts
app.get("/api/accounts", authMiddleware, async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    const stmt = c.env.DB.prepare("SELECT * FROM accounts WHERE user_id = ? ORDER BY created_at DESC");
    const accounts = await stmt.bind(user.id).all();
    return c.json({ accounts: accounts.results });
  } catch (error) {
    console.error("Error fetching accounts:", error);
    return c.json({ error: "Failed to fetch accounts" }, 500);
  }
});

// Create new account
app.post("/api/accounts", authMiddleware, zValidator("json", CreateAccountSchema), async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    const data = c.req.valid("json");
    
    const stmt = c.env.DB.prepare(`
      INSERT INTO accounts (name, initial_balance, user_id, created_at, updated_at)
      VALUES (?, ?, ?, datetime('now'), datetime('now'))
    `);
    const result = await stmt.bind(data.name, data.initial_balance, user.id).run();
    
    if (result.success) {
      const newAccount = await c.env.DB.prepare("SELECT * FROM accounts WHERE id = ?").bind(result.meta.last_row_id).first();
      return c.json({ account: newAccount });
    } else {
      return c.json({ error: "Failed to create account" }, 500);
    }
  } catch (error) {
    console.error("Error creating account:", error);
    return c.json({ error: "Failed to create account" }, 500);
  }
});

// Update account
app.put("/api/accounts/:id", authMiddleware, zValidator("json", UpdateAccountSchema), async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    
    const id = c.req.param("id");
    const data = c.req.valid("json");
    
    const stmt = c.env.DB.prepare(`
      UPDATE accounts 
      SET name = ?, initial_balance = ?, updated_at = datetime('now')
      WHERE id = ? AND user_id = ?
    `);
    const result = await stmt.bind(data.name, data.initial_balance, id, user.id).run();
    
    if (result.success) {
      const updatedAccount = await c.env.DB.prepare("SELECT * FROM accounts WHERE id = ?").bind(id).first();
      return c.json({ account: updatedAccount });
    } else {
      return c.json({ error: "Failed to update account" }, 500);
    }
  } catch (error) {
    console.error("Error updating account:", error);
    return c.json({ error: "Failed to update account" }, 500);
  }
});

// Delete account
app.delete("/api/accounts/:id", authMiddleware, async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    const id = c.req.param("id");
    
    // Set account_id to null for expenses and income related to this account
    await c.env.DB.prepare("UPDATE expenses SET account_id = NULL WHERE account_id = ? AND user_id = ?").bind(id, user.id).run();
    await c.env.DB.prepare("UPDATE income SET account_id = NULL WHERE account_id = ? AND user_id = ?").bind(id, user.id).run();
    
    // Delete transfers related to this account
    await c.env.DB.prepare("DELETE FROM transfers WHERE (from_account_id = ? OR to_account_id = ?) AND user_id = ?").bind(id, id, user.id).run();
    
    const stmt = c.env.DB.prepare("DELETE FROM accounts WHERE id = ? AND user_id = ?");
    const result = await stmt.bind(id, user.id).run();
    
    if (result.success) {
      return c.json({ success: true });
    } else {
      return c.json({ error: "Failed to delete account" }, 500);
    }
  } catch (error) {
    console.error("Error deleting account:", error);
    return c.json({ error: "Failed to delete account" }, 500);
  }
});

// Get account balance
app.get("/api/accounts/:id/balance", authMiddleware, async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    const id = c.req.param("id");
    
    // Get account
    const account = await c.env.DB.prepare("SELECT * FROM accounts WHERE id = ? AND user_id = ?").bind(id, user.id).first() as any;
    if (!account) {
      return c.json({ error: "Account not found" }, 404);
    }
    
    // Calculate total income for this account
    const incomeResult = await c.env.DB.prepare("SELECT SUM(amount) as total FROM income WHERE account_id = ? AND user_id = ?").bind(id, user.id).first() as any;
    const totalIncome = incomeResult?.total || 0;
    
    // Calculate total expenses for this account
    const expenseResult = await c.env.DB.prepare("SELECT SUM(amount) as total FROM expenses WHERE account_id = ? AND user_id = ?").bind(id, user.id).first() as any;
    const totalExpenses = expenseResult?.total || 0;
    
    // Calculate transfers in
    const transfersInResult = await c.env.DB.prepare("SELECT SUM(amount) as total FROM transfers WHERE to_account_id = ? AND user_id = ?").bind(id, user.id).first() as any;
    const transfersIn = transfersInResult?.total || 0;
    
    // Calculate transfers out
    const transfersOutResult = await c.env.DB.prepare("SELECT SUM(amount) as total FROM transfers WHERE from_account_id = ? AND user_id = ?").bind(id, user.id).first() as any;
    const transfersOut = transfersOutResult?.total || 0;
    
    const currentBalance = account.initial_balance + totalIncome - totalExpenses + transfersIn - transfersOut;
    
    return c.json({ 
      balance: currentBalance,
      initial_balance: account.initial_balance,
      total_income: totalIncome,
      total_expenses: totalExpenses,
      transfers_in: transfersIn,
      transfers_out: transfersOut
    });
  } catch (error) {
    console.error("Error calculating balance:", error);
    return c.json({ error: "Failed to calculate balance" }, 500);
  }
});

// Get all transfers
app.get("/api/transfers", authMiddleware, async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    const stmt = c.env.DB.prepare("SELECT * FROM transfers WHERE user_id = ? ORDER BY date DESC, created_at DESC");
    const transfers = await stmt.bind(user.id).all();
    return c.json({ transfers: transfers.results });
  } catch (error) {
    console.error("Error fetching transfers:", error);
    return c.json({ error: "Failed to fetch transfers" }, 500);
  }
});

// Create new transfer
app.post("/api/transfers", authMiddleware, zValidator("json", CreateTransferSchema), async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    const data = c.req.valid("json");
    
    if (data.from_account_id === data.to_account_id) {
      return c.json({ error: "Cannot transfer to the same account" }, 400);
    }
    
    const stmt = c.env.DB.prepare(`
      INSERT INTO transfers (amount, from_account_id, to_account_id, description, date, user_id, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `);
    const result = await stmt.bind(data.amount, data.from_account_id, data.to_account_id, data.description || null, data.date, user.id).run();
    
    if (result.success) {
      const newTransfer = await c.env.DB.prepare("SELECT * FROM transfers WHERE id = ?").bind(result.meta.last_row_id).first();
      return c.json({ transfer: newTransfer });
    } else {
      return c.json({ error: "Failed to create transfer" }, 500);
    }
  } catch (error) {
    console.error("Error creating transfer:", error);
    return c.json({ error: "Failed to create transfer" }, 500);
  }
});

// Delete transfer
app.delete("/api/transfers/:id", authMiddleware, async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    const id = c.req.param("id");
    const stmt = c.env.DB.prepare("DELETE FROM transfers WHERE id = ? AND user_id = ?");
    const result = await stmt.bind(id, user.id).run();
    
    if (result.success) {
      return c.json({ success: true });
    } else {
      return c.json({ error: "Failed to delete transfer" }, 500);
    }
  } catch (error) {
    console.error("Error deleting transfer:", error);
    return c.json({ error: "Failed to delete transfer" }, 500);
  }
});

// Delete category
app.delete("/api/categories/:id", authMiddleware, async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    
    const id = c.req.param("id");
    
    // Check if category exists
    const categoryStmt = c.env.DB.prepare("SELECT is_default, user_id, name FROM categories WHERE id = ?");
    const category = await categoryStmt.bind(id).first() as any;
    
    if (!category) {
      return c.json({ error: "Categoria não encontrada" }, 404);
    }
    
    // Allow deleting if it's the user's category OR if it's a default category
    if (!category.is_default && category.user_id !== user.id) {
      return c.json({ error: "Não autorizado" }, 403);
    }
    
    // Update existing expenses to use "Outros" category
    const updateExpensesStmt = c.env.DB.prepare(`
      UPDATE expenses 
      SET category = 'Outros', updated_at = datetime('now')
      WHERE category = ? AND user_id = ?
    `);
    await updateExpensesStmt.bind(category.name, user.id).run();
    
    // Delete the category
    const deleteStmt = c.env.DB.prepare("DELETE FROM categories WHERE id = ?");
    const result = await deleteStmt.bind(id).run();
    
    if (result.success) {
      return c.json({ success: true });
    } else {
      return c.json({ error: "Failed to delete category" }, 500);
    }
  } catch (error) {
    console.error("Error deleting category:", error);
    return c.json({ error: "Failed to delete category" }, 500);
  }
});

export default app;
