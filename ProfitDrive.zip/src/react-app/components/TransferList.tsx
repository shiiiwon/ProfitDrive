import { useState, useEffect } from 'react';
import { Trash2, Calendar, ArrowRightLeft } from 'lucide-react';
import { Transfer, Account } from '@/shared/types';

interface TransferListProps {
  refreshTrigger?: number;
}

export default function TransferList({ refreshTrigger }: TransferListProps) {
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [transfersRes, accountsRes] = await Promise.all([
        fetch('/api/transfers'),
        fetch('/api/accounts')
      ]);
      
      const transfersData = await transfersRes.json();
      const accountsData = await accountsRes.json();
      
      setTransfers(transfersData.transfers || []);
      setAccounts(accountsData.accounts || []);
    } catch (error) {
      console.error('Failed to fetch transfers:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [refreshTrigger]);

  const handleDelete = async (id: number) => {
    if (!confirm('Tem certeza que deseja excluir esta transferência?')) {
      return;
    }

    try {
      const response = await fetch(`/api/transfers/${id}`, {
        method: 'DELETE',
      });
      
      if (response.ok) {
        setTransfers(prev => prev.filter(t => t.id !== id));
      }
    } catch (error) {
      console.error('Failed to delete transfer:', error);
    }
  };

  const getAccountName = (accountId: number) => {
    const account = accounts.find(a => a.id === accountId);
    return account?.name || 'Conta desconhecida';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-20 bg-gray-200 rounded-xl"></div>
          ))}
        </div>
      </div>
    );
  }

  if (transfers.length === 0) {
    return (
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-12 text-center">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <ArrowRightLeft className="w-8 h-8 text-gray-400" />
        </div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">Nenhuma transferência ainda</h3>
        <p className="text-gray-600">Transfira dinheiro entre suas contas.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Transferências Recentes</h2>
      
      <div className="space-y-4">
        {transfers.map((transfer) => (
          <div
            key={transfer.id}
            className="flex items-center justify-between p-4 border border-gray-200 rounded-xl hover:border-indigo-300 hover:shadow-md transition-all duration-200"
          >
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <ArrowRightLeft className="w-5 h-5 text-indigo-600" />
                <h3 className="font-semibold text-gray-900">
                  {getAccountName(transfer.from_account_id)} → {getAccountName(transfer.to_account_id)}
                </h3>
              </div>
              {transfer.description && (
                <p className="text-sm text-gray-600 mb-2">{transfer.description}</p>
              )}
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <span className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {formatDate(transfer.date)}
                </span>
                <span className="font-semibold text-indigo-600 text-lg">
                  {formatAmount(transfer.amount)}
                </span>
              </div>
            </div>
            
            <button
              onClick={() => handleDelete(transfer.id)}
              className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
              title="Excluir transferência"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
