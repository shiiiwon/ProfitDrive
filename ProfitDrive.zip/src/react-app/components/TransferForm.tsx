import { useState, useEffect } from 'react';
import { ArrowRightLeft } from 'lucide-react';
import { CreateTransfer, Account } from '@/shared/types';

interface TransferFormProps {
  onSubmit: (transfer: CreateTransfer) => void;
  loading?: boolean;
  onAccountsChange?: () => void;
}

export default function TransferForm({ onSubmit, loading, onAccountsChange }: TransferFormProps) {
  const [transfer, setTransfer] = useState<CreateTransfer>({
    amount: 0,
    from_account_id: 0,
    to_account_id: 0,
    description: '',
    date: new Date().toISOString().split('T')[0],
  });
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loadingAccounts, setLoadingAccounts] = useState(true);

  const fetchAccounts = async () => {
    try {
      setLoadingAccounts(true);
      const response = await fetch('/api/accounts');
      const data = await response.json();
      setAccounts(data.accounts || []);
      
      if (data.accounts && data.accounts.length > 0) {
        setTransfer(prev => ({ 
          ...prev, 
          from_account_id: data.accounts[0].id,
          to_account_id: data.accounts.length > 1 ? data.accounts[1].id : data.accounts[0].id
        }));
      }
    } catch (error) {
      console.error('Failed to fetch accounts:', error);
    } finally {
      setLoadingAccounts(false);
    }
  };

  useEffect(() => {
    fetchAccounts();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (transfer.from_account_id === transfer.to_account_id) {
      alert('Não é possível transferir para a mesma conta');
      return;
    }
    
    onSubmit(transfer);
    setTransfer({
      amount: 0,
      from_account_id: accounts[0]?.id || 0,
      to_account_id: accounts.length > 1 ? accounts[1].id : accounts[0]?.id || 0,
      description: '',
      date: new Date().toISOString().split('T')[0],
    });
    
    if (onAccountsChange) {
      onAccountsChange();
    }
  };

  if (accounts.length < 2) {
    return (
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">
        <div className="flex items-center gap-3 mb-4">
          <div className="bg-gradient-to-br from-indigo-500 to-indigo-600 p-3 rounded-xl">
            <ArrowRightLeft className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Transferências</h2>
        </div>
        <div className="text-center py-8">
          <p className="text-gray-600">Crie pelo menos 2 contas para fazer transferências.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="bg-gradient-to-br from-indigo-500 to-indigo-600 p-3 rounded-xl">
          <ArrowRightLeft className="w-6 h-6 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Nova Transferência</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Valor
            </label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 font-medium">
                R$
              </span>
              <input
                type="number"
                step="0.01"
                value={transfer.amount || ''}
                onChange={(e) => setTransfer(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
                placeholder="0,00"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Data
            </label>
            <input
              type="date"
              value={transfer.date}
              onChange={(e) => setTransfer(prev => ({ ...prev, date: e.target.value }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              De
            </label>
            <select
              value={transfer.from_account_id}
              onChange={(e) => setTransfer(prev => ({ ...prev, from_account_id: parseInt(e.target.value) }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
              required
              disabled={loadingAccounts}
            >
              {accounts.map(account => (
                <option key={account.id} value={account.id}>
                  {account.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Para
            </label>
            <select
              value={transfer.to_account_id}
              onChange={(e) => setTransfer(prev => ({ ...prev, to_account_id: parseInt(e.target.value) }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
              required
              disabled={loadingAccounts}
            >
              {accounts.map(account => (
                <option key={account.id} value={account.id}>
                  {account.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Descrição (opcional)
          </label>
          <input
            type="text"
            value={transfer.description}
            onChange={(e) => setTransfer(prev => ({ ...prev, description: e.target.value }))}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
            placeholder="Ex: Transferência para reserva de emergência"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gradient-to-r from-indigo-500 to-indigo-600 text-white py-4 px-6 rounded-xl font-semibold hover:from-indigo-600 hover:to-indigo-700 disabled:opacity-50 transition-all duration-200 shadow-lg hover:shadow-xl"
        >
          {loading ? 'Transferindo...' : 'Fazer Transferência'}
        </button>
      </form>
    </div>
  );
}
