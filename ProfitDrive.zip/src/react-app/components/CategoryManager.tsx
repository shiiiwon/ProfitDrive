import { useState, useEffect } from 'react';
import { Tag, Plus, Edit2, Trash2, X, Check } from 'lucide-react';
import { Category, CreateCategory } from '@/shared/types';

export default function CategoryManager() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingName, setEditingName] = useState('');
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [error, setError] = useState('');

  const fetchCategories = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/categories');
      const data = await response.json();
      setCategories(data.categories || []);
    } catch (error) {
      console.error('Failed to fetch categories:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const handleAddCategory = async () => {
    if (!newCategoryName.trim()) {
      setError('Nome da categoria não pode estar vazio');
      return;
    }

    try {
      setError('');
      const response = await fetch('/api/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newCategoryName.trim() } as CreateCategory),
      });

      if (response.ok) {
        const data = await response.json();
        setCategories(prev => [...prev, data.category]);
        setNewCategoryName('');
        setIsAddingNew(false);
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Falha ao criar categoria');
      }
    } catch (error) {
      console.error('Failed to add category:', error);
      setError('Falha ao criar categoria');
    }
  };

  const handleUpdateCategory = async (id: number) => {
    if (!editingName.trim()) {
      setError('Nome da categoria não pode estar vazio');
      return;
    }

    try {
      setError('');
      const response = await fetch(`/api/categories/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: editingName.trim() }),
      });

      if (response.ok) {
        const data = await response.json();
        setCategories(prev => prev.map(cat => cat.id === id ? data.category : cat));
        setEditingId(null);
        setEditingName('');
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Falha ao atualizar categoria');
      }
    } catch (error) {
      console.error('Failed to update category:', error);
      setError('Falha ao atualizar categoria');
    }
  };

  const handleDeleteCategory = async (id: number) => {
    const category = categories.find(cat => cat.id === id);
    const message = category?.is_default
      ? 'Tem certeza que deseja excluir esta categoria padrão? Despesas nesta categoria serão movidas para "Outros".'
      : 'Tem certeza? Despesas nesta categoria serão movidas para "Outros".';
    
    if (!confirm(message)) {
      return;
    }

    try {
      setError('');
      const response = await fetch(`/api/categories/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        setCategories(prev => prev.filter(cat => cat.id !== id));
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Falha ao excluir categoria');
      }
    } catch (error) {
      console.error('Failed to delete category:', error);
      setError('Falha ao excluir categoria');
    }
  };

  const startEditing = (category: Category) => {
    setEditingId(category.id);
    setEditingName(category.name);
    setError('');
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditingName('');
    setError('');
  };

  const getCategoryColor = (isDefault: boolean) => {
    return isDefault 
      ? 'bg-gray-100 text-gray-800 border-gray-200' 
      : 'bg-emerald-50 text-emerald-800 border-emerald-200';
  };

  if (loading) {
    return (
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-12 bg-gray-200 rounded-xl"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="bg-gradient-to-br from-purple-500 to-purple-600 p-3 rounded-xl">
          <Tag className="w-6 h-6 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Gerenciar Categorias</h2>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-sm">
          {error}
        </div>
      )}

      <div className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-gray-600">Todas as Categorias</h3>
          {!isAddingNew && (
            <button
              onClick={() => setIsAddingNew(true)}
              className="flex items-center gap-2 px-3 py-1 text-sm text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors"
            >
              <Plus className="w-4 h-4" />
              Nova Categoria
            </button>
          )}
        </div>

        {/* Add New Category Form */}
        {isAddingNew && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAddCategory();
                  if (e.key === 'Escape') {
                    setIsAddingNew(false);
                    setNewCategoryName('');
                    setError('');
                  }
                }}
                className="flex-1 px-3 py-2 border border-emerald-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                placeholder="Nome da categoria"
                autoFocus
              />
              <button
                onClick={handleAddCategory}
                className="p-2 text-emerald-600 hover:bg-emerald-100 rounded-lg transition-colors"
                title="Salvar"
              >
                <Check className="w-5 h-5" />
              </button>
              <button
                onClick={() => {
                  setIsAddingNew(false);
                  setNewCategoryName('');
                  setError('');
                }}
                className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                title="Cancelar"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* Categories List */}
        {categories.length > 0 ? (
          <div className="space-y-2">
            {categories.map(category => (
              <div
                key={category.id}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg border ${getCategoryColor(category.is_default)}`}
              >
                {editingId === category.id ? (
                  <>
                    <input
                      type="text"
                      value={editingName}
                      onChange={(e) => setEditingName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleUpdateCategory(category.id);
                        if (e.key === 'Escape') cancelEditing();
                      }}
                      className="flex-1 px-2 py-1 border border-emerald-300 rounded focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm bg-white"
                      autoFocus
                    />
                    <button
                      onClick={() => handleUpdateCategory(category.id)}
                      className="p-1 text-emerald-600 hover:bg-emerald-100 rounded transition-colors"
                      title="Salvar"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                    <button
                      onClick={cancelEditing}
                      className="p-1 text-gray-600 hover:bg-gray-100 rounded transition-colors"
                      title="Cancelar"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </>
                ) : (
                  <>
                    <span className="flex-1 text-sm font-medium">
                      {category.name}
                      {category.is_default && <span className="ml-2 text-xs text-gray-500">(padrão)</span>}
                    </span>
                    <button
                      onClick={() => startEditing(category)}
                      className="p-1 text-gray-600 hover:bg-emerald-100 rounded transition-colors"
                      title="Editar"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteCategory(category.id)}
                      className="p-1 text-red-600 hover:bg-red-100 rounded transition-colors"
                      title="Excluir"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500 text-sm">
            Nenhuma categoria ainda.
            {!isAddingNew && (
              <button
                onClick={() => setIsAddingNew(true)}
                className="block mx-auto mt-2 text-emerald-600 hover:text-emerald-700 font-medium"
              >
                Criar sua primeira categoria
              </button>
            )}
          </div>
        )}
      </div>

      <p className="text-xs text-gray-500 mt-4">
        Todas as categorias podem ser editadas e excluídas. Ao excluir uma categoria, as despesas serão movidas para "Outros".
      </p>
    </div>
  );
}
