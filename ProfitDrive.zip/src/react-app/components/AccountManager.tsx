import { useState, useEffect } from 'react';
import { Wallet, Plus, Edit2, Trash2, X, Check, TrendingUp, TrendingDown } from 'lucide-react';
import { Account, CreateAccount } from '@/shared/types';

export default function AccountManager() {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [balances, setBalances] = useState<Record<number, any>>({});
  const [loading, setLoading] = useState(true);
  const [newAccountName, setNewAccountName] = useState('');
  const [newAccountBalance, setNewAccountBalance] = useState(0);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingName, setEditingName] = useState('');
  const [editingBalance, setEditingBalance] = useState(0);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [error, setError] = useState('');

  const fetchAccounts = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/accounts');
      const data = await response.json();
      setAccounts(data.accounts || []);
      
      // Fetch balances for each account
      const balancePromises = (data.accounts || []).map(async (account: Account) => {
        const balanceResponse = await fetch(`/api/accounts/${account.id}/balance`);
        const balanceData = await balanceResponse.json();
        return { id: account.id, ...balanceData };
      });
      
      const balanceResults = await Promise.all(balancePromises);
      const balanceMap: Record<number, any> = {};
      balanceResults.forEach(result => {
        balanceMap[result.id] = result;
      });
      setBalances(balanceMap);
    } catch (error) {
      console.error('Failed to fetch accounts:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAccounts();
  }, []);

  const handleAddAccount = async () => {
    if (!newAccountName.trim()) {
      setError('Nome da conta não pode estar vazio');
      return;
    }

    try {
      setError('');
      const response = await fetch('/api/accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          name: newAccountName.trim(), 
          initial_balance: newAccountBalance 
        } as CreateAccount),
      });

      if (response.ok) {
        await fetchAccounts();
        setNewAccountName('');
        setNewAccountBalance(0);
        setIsAddingNew(false);
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Falha ao criar conta');
      }
    } catch (error) {
      console.error('Failed to add account:', error);
      setError('Falha ao criar conta');
    }
  };

  const handleUpdateAccount = async (id: number) => {
    if (!editingName.trim()) {
      setError('Nome da conta não pode estar vazio');
      return;
    }

    try {
      setError('');
      const response = await fetch(`/api/accounts/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          name: editingName.trim(), 
          initial_balance: editingBalance 
        }),
      });

      if (response.ok) {
        await fetchAccounts();
        setEditingId(null);
        setEditingName('');
        setEditingBalance(0);
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Falha ao atualizar conta');
      }
    } catch (error) {
      console.error('Failed to update account:', error);
      setError('Falha ao atualizar conta');
    }
  };

  const handleDeleteAccount = async (id: number) => {
    if (!confirm('Tem certeza? Despesas e ganhos desta conta ficarão sem conta atribuída.')) {
      return;
    }

    try {
      setError('');
      const response = await fetch(`/api/accounts/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        await fetchAccounts();
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Falha ao excluir conta');
      }
    } catch (error) {
      console.error('Failed to delete account:', error);
      setError('Falha ao excluir conta');
    }
  };

  const startEditing = (account: Account) => {
    setEditingId(account.id);
    setEditingName(account.name);
    setEditingBalance(account.initial_balance);
    setError('');
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditingName('');
    setEditingBalance(0);
    setError('');
  };

  if (loading) {
    return (
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-20 bg-gray-200 rounded-xl"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 p-3 rounded-xl">
          <Wallet className="w-6 h-6 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Contas Bancárias</h2>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-sm">
          {error}
        </div>
      )}

      <div className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-gray-600">Suas Contas</h3>
          {!isAddingNew && (
            <button
              onClick={() => setIsAddingNew(true)}
              className="flex items-center gap-2 px-3 py-1 text-sm text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
            >
              <Plus className="w-4 h-4" />
              Nova Conta
            </button>
          )}
        </div>

        {/* Add New Account Form */}
        {isAddingNew && (
          <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-xl">
            <div className="space-y-3">
              <input
                type="text"
                value={newAccountName}
                onChange={(e) => setNewAccountName(e.target.value)}
                className="w-full px-3 py-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                placeholder="Nome da conta"
                autoFocus
              />
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">
                  R$
                </span>
                <input
                  type="number"
                  step="0.01"
                  value={newAccountBalance || ''}
                  onChange={(e) => setNewAccountBalance(parseFloat(e.target.value) || 0)}
                  className="w-full pl-10 pr-3 py-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                  placeholder="Saldo inicial"
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleAddAccount}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                >
                  Adicionar
                </button>
                <button
                  onClick={() => {
                    setIsAddingNew(false);
                    setNewAccountName('');
                    setNewAccountBalance(0);
                    setError('');
                  }}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors text-sm font-medium"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Accounts List */}
        {accounts.length > 0 ? (
          <div className="space-y-3">
            {accounts.map(account => {
              const balance = balances[account.id];
              const currentBalance = balance?.balance || 0;
              const isPositive = currentBalance >= 0;
              
              return (
                <div
                  key={account.id}
                  className="p-4 rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-md transition-all"
                >
                  {editingId === account.id ? (
                    <div className="space-y-3">
                      <input
                        type="text"
                        value={editingName}
                        onChange={(e) => setEditingName(e.target.value)}
                        className="w-full px-3 py-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        autoFocus
                      />
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">
                          R$
                        </span>
                        <input
                          type="number"
                          step="0.01"
                          value={editingBalance || ''}
                          onChange={(e) => setEditingBalance(parseFloat(e.target.value) || 0)}
                          className="w-full pl-10 pr-3 py-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleUpdateAccount(account.id)}
                          className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors"
                          title="Salvar"
                        >
                          <Check className="w-5 h-5" />
                        </button>
                        <button
                          onClick={cancelEditing}
                          className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                          title="Cancelar"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-gray-900">{account.name}</h3>
                          {isPositive ? (
                            <TrendingUp className="w-4 h-4 text-green-600" />
                          ) : (
                            <TrendingDown className="w-4 h-4 text-red-600" />
                          )}
                        </div>
                        <div className="text-sm text-gray-600 space-y-1">
                          <p>Saldo inicial: <span className="font-medium">R${account.initial_balance.toFixed(2)}</span></p>
                          <p className={`font-bold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
                            Saldo atual: R${currentBalance.toFixed(2)}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => startEditing(account)}
                          className="p-2 text-gray-600 hover:bg-blue-100 rounded-lg transition-colors"
                          title="Editar"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteAccount(account.id)}
                          className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                          title="Excluir"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500 text-sm">
            Nenhuma conta ainda.
            {!isAddingNew && (
              <button
                onClick={() => setIsAddingNew(true)}
                className="block mx-auto mt-2 text-blue-600 hover:text-blue-700 font-medium"
              >
                Criar sua primeira conta
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
