import { Trash2, Calendar, Tag, DollarSign } from 'lucide-react';
import { Income } from '@/shared/types';

interface IncomeListProps {
  income: Income[];
  onDelete: (id: number) => void;
  loading?: boolean;
}

export default function IncomeList({ income, onDelete, loading }: IncomeListProps) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(amount);
  };

  const getSourceColor = (source: string) => {
    const colors: Record<string, string> = {
      'Uber': 'bg-black text-white',
      '99': 'bg-orange-100 text-orange-800',
      'DiDi': 'bg-orange-100 text-orange-800',
      'Cabify': 'bg-purple-100 text-purple-800',
      'InDriver': 'bg-blue-100 text-blue-800',
      'Outros': 'bg-gray-100 text-gray-800'
    };
    return colors[source] || colors['Outros'];
  };

  if (loading) {
    return (
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-20 bg-gray-200 rounded-xl"></div>
          ))}
        </div>
      </div>
    );
  }

  if (income.length === 0) {
    return (
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-12 text-center">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <DollarSign className="w-8 h-8 text-gray-400" />
        </div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">Nenhum ganho ainda</h3>
        <p className="text-gray-600">Comece a rastrear seus ganhos para ver o lucro líquido.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Ganhos Recentes</h2>
      
      <div className="space-y-4">
        {income.map((item) => (
          <div
            key={item.id}
            className="flex items-center justify-between p-4 border border-gray-200 rounded-xl hover:border-purple-300 hover:shadow-md transition-all duration-200"
          >
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h3 className="font-semibold text-gray-900">{item.description}</h3>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${getSourceColor(item.source)}`}>
                  <Tag className="w-3 h-3 inline mr-1" />
                  {item.source}
                </span>
              </div>
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <span className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {formatDate(item.date)}
                </span>
                <span className="font-semibold text-purple-600 text-lg">
                  {formatAmount(item.amount)}
                </span>
              </div>
            </div>
            
            <button
              onClick={() => onDelete(item.id)}
              className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
              title="Excluir ganho"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
