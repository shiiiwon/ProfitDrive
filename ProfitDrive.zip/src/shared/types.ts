import z from "zod";

export const ExpenseSchema = z.object({
  id: z.number(),
  amount: z.number().positive(),
  description: z.string().min(1),
  category: z.string().min(1),
  date: z.string(),
  account_id: z.number().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateExpenseSchema = z.object({
  amount: z.number().positive(),
  description: z.string().min(1),
  category: z.string().min(1),
  date: z.string(),
  account_id: z.number().nullable(),
});

export const CategorySchema = z.object({
  id: z.number(),
  name: z.string().min(1),
  user_id: z.string(),
  is_default: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateCategorySchema = z.object({
  name: z.string().min(1).max(50),
});

export const UpdateCategorySchema = z.object({
  name: z.string().min(1).max(50),
});

export const AIInsightSchema = z.object({
  summary: z.string(),
  tips: z.array(z.string()),
  categoryBreakdown: z.record(z.string(), z.number()),
  spendingTrend: z.enum(['increasing', 'decreasing', 'stable']),
});

export type Expense = z.infer<typeof ExpenseSchema>;
export type CreateExpense = z.infer<typeof CreateExpenseSchema>;
export type Category = z.infer<typeof CategorySchema>;
export type CreateCategory = z.infer<typeof CreateCategorySchema>;
export type UpdateCategory = z.infer<typeof UpdateCategorySchema>;
export type AIInsight = z.infer<typeof AIInsightSchema>;

export const IncomeSchema = z.object({
  id: z.number(),
  amount: z.number().positive(),
  description: z.string().min(1),
  source: z.string().min(1),
  date: z.string(),
  account_id: z.number().nullable(),
  user_id: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateIncomeSchema = z.object({
  amount: z.number().positive(),
  description: z.string().min(1),
  source: z.string().min(1),
  date: z.string(),
  account_id: z.number().nullable(),
});

export type Income = z.infer<typeof IncomeSchema>;
export type CreateIncome = z.infer<typeof CreateIncomeSchema>;

export const EXPENSE_CATEGORIES = [
  'Alimentação',
  'Transporte',
  'Compras',
  'Entretenimento',
  'Contas e Utilidades',
  'Saúde',
  'Viagem',
  'Educação',
  'Cuidados Pessoais',
  'Outros'
] as const;

export const INCOME_SOURCES = [
  'Uber',
  '99',
  'DiDi',
  'Cabify',
  'InDriver',
  'Outros'
] as const;

export const AccountSchema = z.object({
  id: z.number(),
  name: z.string().min(1),
  initial_balance: z.number(),
  user_id: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateAccountSchema = z.object({
  name: z.string().min(1).max(50),
  initial_balance: z.number(),
});

export const UpdateAccountSchema = z.object({
  name: z.string().min(1).max(50),
  initial_balance: z.number(),
});

export const TransferSchema = z.object({
  id: z.number(),
  amount: z.number().positive(),
  from_account_id: z.number(),
  to_account_id: z.number(),
  description: z.string().nullable(),
  date: z.string(),
  user_id: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateTransferSchema = z.object({
  amount: z.number().positive(),
  from_account_id: z.number(),
  to_account_id: z.number(),
  description: z.string().optional(),
  date: z.string(),
});

export type Account = z.infer<typeof AccountSchema>;
export type CreateAccount = z.infer<typeof CreateAccountSchema>;
export type UpdateAccount = z.infer<typeof UpdateAccountSchema>;
export type Transfer = z.infer<typeof TransferSchema>;
export type CreateTransfer = z.infer<typeof CreateTransferSchema>;
