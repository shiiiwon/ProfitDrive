
ALTER TABLE income DROP COLUMN account_id;
ALTER TABLE expenses DROP COLUMN account_id;
DROP TABLE transfers;
DROP TABLE accounts;
