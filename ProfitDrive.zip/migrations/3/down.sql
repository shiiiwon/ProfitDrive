
DROP INDEX idx_categories_user_id;
DROP TABLE categories;
