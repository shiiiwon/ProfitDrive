
DROP INDEX idx_income_date;
DROP INDEX idx_income_user_id;
DROP TABLE income;
