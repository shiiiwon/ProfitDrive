
CREATE TABLE categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  user_id TEXT NOT NULL,
  is_default BOOLEAN DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_categories_user_id ON categories(user_id);

INSERT INTO categories (name, user_id, is_default) VALUES 
  ('Alimentação', 'system', 1),
  ('Transporte', 'system', 1),
  ('Compras', 'system', 1),
  ('Entretenimento', 'system', 1),
  ('Contas e Utilidades', 'system', 1),
  ('Saúde', 'system', 1),
  ('Viagem', 'system', 1),
  ('Educação', 'system', 1),
  ('Cuidados Pessoais', 'system', 1),
  ('Outros', 'system', 1);
